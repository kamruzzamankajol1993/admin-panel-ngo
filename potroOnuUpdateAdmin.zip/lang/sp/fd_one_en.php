<?php
return [
    'other_info'=>'Other Document',
];
