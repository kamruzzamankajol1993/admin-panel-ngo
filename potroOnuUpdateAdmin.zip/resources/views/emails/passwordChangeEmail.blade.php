<h1>Set Your Account Password</h1>

Click The Link to Add Password:
<a href="{{ route('accountPasswordChange', $id) }}">Click Here</a>

<h2>------------------</h2>
<p><b>NGO Affairs Bureau</b> <br>
    Prime Minister's Office <br>
    Plot-E-13/B, Agargaon. Sher-e-Bangla Nagar, Dhaka-1207
</p>

