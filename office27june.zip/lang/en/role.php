<?php
return [


	'rollist'=>'রোলের তালিকা ',
	'addnewrol'=>'নতুন রোল যুক্ত করুন ',
	'perlist'=>'অনুমতি তালিকা',
    'role'=>'রোল',
    'rolename'=>'রোল নাম ',
    'all'=>'সব',
    'rolupdate'=>'রোল আপডেট করুন ',


   'dataentry'=>'ডাটা প্রবেশ করান',
   'file'=>'ফাইল',


   'division'=>'বিভাগ',
   'district'=>'জেলা',
   'pollicestation'=>'থানার নাম',
   'postoffice'=>'পোস্ট অফিস ',
   'postcode'=>'পোস্ট কোড',







];

?>
