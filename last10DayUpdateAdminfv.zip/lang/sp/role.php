<?php
return [


	'rollist'=>'Role List',
	'addnewrol'=>'Add New Role',
	'perlist'=>'Permission',
    'role'=>'Role',
    'rolename'=>'Role Name',
    'all'=>'All',
    'rolupdate'=>'Update Role',



    'dataentry'=>'Data Entry',
    'file'=>'File',



    'division'=>'Division',
   'district'=>'District',
   'pollicestation'=>'Police Station',
   'postoffice'=>'Post Office',
   'postcode'=>'Post Code',






];

?>
