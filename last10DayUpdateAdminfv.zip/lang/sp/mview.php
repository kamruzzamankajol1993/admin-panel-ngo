<?php
return [
    'ttOne'=>'Provide the name and title of the chief executive',
    'ttTwo'=>'Name of Chief Executive',
    'ttThree'=>'Title of Chief Executive',
    'place'=>'Place',
];


?>
