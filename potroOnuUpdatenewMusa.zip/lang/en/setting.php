<?php
return [


    'managesetting'=>'সেটিং পরিচালনা করুন',
    'aboutsetting'=>'এবাউট সেটিং ',
    'passwordsetting'=>'পাসওয়ার্ড  সেটিং ',
    'about'=>'এবাউট ',
    'address'=>'ঠিকানা',
    'oldpassword'=>'পুরানো পাসওয়ার্ড',
    'newpassword'=>'নতুন পাসওয়ার্ড',
    'confirmpassword'=>'পাসওয়ার্ড নিশ্চিত করুন',
    'editProfile'=>'আপনার প্রোফাইল সম্পাদনা করুন',
    'profile'=>'প্রোফাইল',
    'Admininfo'=>'অ্যাডমিন ইনফরমেশন ',
    
       

     




];

?>